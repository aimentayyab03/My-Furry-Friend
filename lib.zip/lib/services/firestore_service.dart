// firestore_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> updateUserDocument(String userId, Map<String, dynamic> data) async {
    try {
      final userDocRef = _db.collection('users').doc(userId);
      final userSnapshot = await userDocRef.get();

      if (userSnapshot.exists) {
        // Update the document if it exists
        await userDocRef.update(data);
      } else {
        // Document does not exist, create it
        await userDocRef.set(data);
      }
    } catch (e) {
      print('Error updating Firestore document: $e');
    }
  }
}
