import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Sign Up with Email and Password
  Future<UserCredential> signUpWithEmailPassword(String email, String password) async {
    try {
      final UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Add user to Firestore
      await _firestore.collection('users').doc(userCredential.user?.uid).set({
        'email': email,
        'createdAt': FieldValue.serverTimestamp(),
      });

      return userCredential;
    } catch (e) {
      throw Exception('Sign-Up failed: $e');
    }
  }

  /// Sign In with Email and Password
  Future<UserCredential> signInWithEmailAndPassword(String email, String password) async {
    try {
      return await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      throw Exception('Login failed: $e');
    }
  }

  /// Google Sign-In with Silent Sign-In Check
  Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleSignIn googleSignIn = GoogleSignIn();

      // Silent sign-in
      final GoogleSignInAccount? googleUser = await googleSignIn.signInSilently();

      // If silent sign-in fails, show the account picker
      final GoogleSignInAccount? account =
          googleUser ?? await googleSignIn.signIn();

      if (account == null) {
        // User canceled sign-in
        return null;
      }

      // Authenticate and get tokens
      final GoogleSignInAuthentication googleAuth = await account.authentication;
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential userCredential = await _auth.signInWithCredential(credential);

      // Add user to Firestore if not already present
      final user = userCredential.user;
      if (user != null) {
        await _firestore.collection('users').doc(user.uid).set({
          'email': user.email,
          'displayName': user.displayName,
          'photoURL': user.photoURL,
          'lastSignInTime': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }

      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw Exception("Google Sign-In failed: ${e.message}");
    } catch (e) {
      throw Exception("Google Sign-In failed: $e");
    }
  }

  /// Sign Out
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      final GoogleSignIn googleSignIn = GoogleSignIn();
      await googleSignIn.signOut();
    } catch (e) {
      throw Exception('Sign out failed: $e');
    }
  }

  /// Send Password Reset Email
  Future<void> sendPasswordResetLink(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } catch (e) {
      throw Exception('Error sending password reset email: $e');
    }
  }

  /// Get Current User
  User? getCurrentUser() {
    return _auth.currentUser;
  }

  /// Check if User is Authenticated
  bool isAuthenticated() {
    return _auth.currentUser != null;
  }

  /// Send Email Verification
  Future<void> sendEmailVerification() async {
    try {
      final user = _auth.currentUser;
      if (user != null && !user.emailVerified) {
        await user.sendEmailVerification();
      }
    } catch (e) {
      throw Exception('Error sending email verification: $e');
    }
  }

  Future<bool> userExists(String email) async {
    try {
      // Query Firestore to check if a user with the given email exists
      final QuerySnapshot userSnapshot = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      // Return true if at least one document is found
      return userSnapshot.docs.isNotEmpty;
    } catch (e) {
      throw Exception('Error checking if user exists: $e');
    }
  }

  Future<DocumentSnapshot<Map<String, dynamic>>?> getUserByEmail(String email) async {
    try {
      final querySnapshot = await _firestore
          .collection('users')
          .where('email', isEqualTo: email)
          .limit(1)
          .get();

      // Check if a user document was found
      if (querySnapshot.docs.isNotEmpty) {
        return querySnapshot.docs.first; // Return the first matching document
      }
      return null; // No user found
    } catch (e) {
      print("Error fetching user by email: $e");
      return null;
    }
  }


  /// Update User Profile (Display Name, Photo URL, etc.)
  Future<void> updateUserProfile({String? displayName, String? photoURL}) async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        await user.updateProfile(displayName: displayName, photoURL: photoURL);
        await user.reload();
      }
    } catch (e) {
      throw Exception('Error updating user profile: $e');
    }
  }

  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> updateUserDocument(String userId, Map<String, dynamic> data) async {
    try {
      final userDocRef = _db.collection('users').doc(userId);
      final userSnapshot = await userDocRef.get();

      if (userSnapshot.exists) {
        // Update the document if it exists
        await userDocRef.update(data);
      } else {
        // Document does not exist, create it
        await userDocRef.set(data);
      }
    } catch (e) {
      print('Error updating Firestore document: $e');
    }
  }

  /// Delete User Account
  Future<void> deleteUserAccount() async {
    try {
      final user = _auth.currentUser;
      if (user != null) {
        await user.delete();
      }
    } catch (e) {
      throw Exception('Error deleting user account: $e');
    }
  }
}
