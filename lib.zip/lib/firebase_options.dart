
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBdclQse010oWMmsrxTzltTiJo9jIQi0pY',
    appId: '1:994906740658:web:f0002bdb1b142c35c2f6ab',
    messagingSenderId: '994906740658',
    projectId: 'my-furry-friend-fyp1',
    authDomain: 'my-furry-friend-fyp1.firebaseapp.com',
    storageBucket: 'my-furry-friend-fyp1.firebasestorage.app',
    measurementId: 'G-0WECYFD47B',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyCx_M69H6N8tsN6fw0kZlYdzXR6c-8m2eM',
    appId: '1:994906740658:android:0409b2ca7dcb3cdcc2f6ab',
    messagingSenderId: '994906740658',
    projectId: 'my-furry-friend-fyp1',
    storageBucket: 'my-furry-friend-fyp1.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyBNL2Y9mOHeqFpepjQAmj46HfiWuaKLlK4',
    appId: '1:994906740658:ios:6076054af2807fe8c2f6ab',
    messagingSenderId: '994906740658',
    projectId: 'my-furry-friend-fyp1',
    storageBucket: 'my-furry-friend-fyp1.firebasestorage.app',
    androidClientId: '994906740658-kqhp12svujgu9abba34ivfpcbj1kfkdn.apps.googleusercontent.com',
    iosClientId: '994906740658-kf9de8mfa7vlhqjsdrpplp4gpv8496c3.apps.googleusercontent.com',
    iosBundleId: 'com.example.mff',
  );
}
