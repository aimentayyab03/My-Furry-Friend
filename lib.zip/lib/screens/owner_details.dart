import 'package:flutter/material.dart';

class OwnerDetails extends StatelessWidget {
  final String email;
  final String password;
  final String username;

  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController petNameController = TextEditingController();
  final TextEditingController petAgeController = TextEditingController();
  final TextEditingController petColorController = TextEditingController();

  OwnerDetails({super.key, required this.email, required this.password, required this.username});

  void validation(BuildContext context) {
    if (nameController.text.isEmpty || phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all required fields")),
      );
    } else if (petNameController.text.isEmpty ||
        petAgeController.text.isEmpty ||
        petColorController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill in all pet details")),
      );
    }
    else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Registration Successful")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pet Owner Details"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Enter Details",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Name',
                fillColor: Color(0xfffb3e0dc),
                filled: true,
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: phoneController,
              decoration: const InputDecoration(
                labelText: 'Phone Number',
                fillColor: Color(0xfffb3e0dc),
                filled: true,
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: petNameController,
              decoration: const InputDecoration(
                labelText: 'Pet Name',
                fillColor: Color(0xfffb3e0dc),
                filled: true,
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: petAgeController,
              decoration: const InputDecoration(
                labelText: 'Pet Age',
                fillColor: Color(0xfffb3e0dc),
                filled: true,
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: petColorController,
              decoration: const InputDecoration(
                labelText: 'Pet Color',
                fillColor: Color(0xfffb3e0dc),
                filled: true,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                validation(context);
              },
              child: const Text("Submit"),
            ),
          ],
        ),
      ),
    );
  }
}
