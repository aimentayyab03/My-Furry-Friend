// import 'package:flutter/material.dart';
// import 'package:mff/services/auth.dart';
// import 'package:mff/screens/login.dart';
//
// class Otpverification extends StatefulWidget {
//   final String email;
//
//   const Otpverification({super.key, required this.email});
//
//   @override
//   State<Otpverification> createState() => _OtpverificationState();
// }
//
// class _OtpverificationState extends State<Otpverification> {
//   final otpController = TextEditingController();
//   final AuthService _authService = AuthService();
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Verify OTP')),
//       body: Padding(
//         padding: const EdgeInsets.all(20.0),
//         child: Column(
//           children: [
//             const Text(
//               'Enter the OTP sent to your email',
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 20),
//             TextField(
//               controller: otpController,
//               decoration: const InputDecoration(labelText: 'OTP'),
//             ),
//             const SizedBox(height: 30),
//             ElevatedButton(
//               onPressed: () async {
//                 final otp = otpController.text;
//
//                 if (await _authService.verifyOTP(widget.email, otp)) {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text("Email verified successfully!")),
//                   );
//
//                   // Navigate to Login or Home Screen
//                   Navigator.pushReplacement(
//                     context,
//                     MaterialPageRoute(builder: (context) => const Login()),
//                   );
//                 } else {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text("Invalid OTP. Please try again.")),
//                   );
//                 }
//               },
//               child: const Text('Verify OTP'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
