import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mff/screens/BreedDetection.dart';
import 'package:mff/screens/login.dart';
import 'package:mff/screens/planner_screen.dart';
import 'package:mff/screens/health_screen.dart';
import 'package:mff/screens/social_screen.dart';
import 'package:mff/screens/profile_screen.dart';

class Pethomepage extends StatefulWidget {
  const Pethomepage({super.key});

  @override
  State<Pethomepage> createState() => _PethomepageState();
}

class _PethomepageState extends State<Pethomepage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text('My Furry Friend'),
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu), // Tri-bar menu icon
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: const [
          Icon(Icons.calendar_today),
          SizedBox(width: 16),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.purple.shade200,
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'My Furry Friend',
                    style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Your pet’s personalized diary',
                    style: TextStyle(fontSize: 14, color: Colors.white70),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home, color: Colors.purple),
              title: const Text('Home'),
              onTap: () {
                Navigator.pop(context); // Close the drawer
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings, color: Colors.purple),
              title: const Text('Settings'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Logout'),
              onTap: () async {
                await _auth.signOut();
                goToLogin(context);
              },
            ),
          ],
        ),
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: _firestore.collection('users').doc(_auth.currentUser?.uid).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(
              child: Text(
                'No pet details found. Please add your pet details.',
                style: TextStyle(fontSize: 16, color: Colors.purple),
              ),
            );
          }

          final pet = snapshot.data!.data() as Map<String, dynamic>?;
          if (pet == null || pet['pet'] == null) {
            return const Center(
              child: Text(
                'No pet details found. Please add your pet details.',
                style: TextStyle(fontSize: 16, color: Colors.purple),
              ),
            );
          }

          final petDetails = pet['pet'] as Map<String, dynamic>;

          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Pet Image and Intro Row
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "This is Diary!",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.purple,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              "Take a look at how ${petDetails['name']}’s day was planned.",
                              style: const TextStyle(fontSize: 14, color: Colors.black87),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.purple.shade100,
                        backgroundImage: petDetails['image'] != null
                            ? NetworkImage(petDetails['image'])
                            : null,
                        child: petDetails['image'] == null
                            ? const Icon(Icons.pets, size: 50, color: Colors.white)
                            : null,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Pet Name
                  Text(
                    petDetails['name'] ?? 'Unknown',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Pet Info
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.purple.shade50,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _PetInfoTile(label: 'Age', value: petDetails['age'] ?? 'Unknown'),
                        _PetInfoTile(label: 'Weight', value: petDetails['weight'] ?? 'Unknown'),
                        _PetInfoTile(label: 'Height', value: petDetails['height'] ?? 'Unknown'),
                        _PetInfoTile(label: 'Color', value: petDetails['color'] ?? 'Unknown'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  const Text(
                    'About Pet',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.purple),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    petDetails['about'] ?? 'No description available.',
                    style: const TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 20),

                  // Bottom Navigation Buttons
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _NavButton(
                          icon: Icons.health_and_safety,
                          label: 'Health',
                          targetScreen: HealthScreen()),
                      _NavButton(
                          icon: Icons.group,
                          label: 'Social',
                          targetScreen: SocialScreen()),
                      _NavButton(
                          icon: Icons.account_circle,
                          label: 'Profile',
                          targetScreen: ProfileScreen()),
                      _NavButton(
                        icon: Icons.account_circle,
                        label: 'Breed',
                        targetScreen: Breeddetection(),
                      ),
                      _NavButton(
                          icon: Icons.event,
                          label: 'Planner',
                          targetScreen: PlannerScreen()),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  goToLogin(BuildContext context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const Login()),
    );
  }
}

class _PetInfoTile extends StatelessWidget {
  final String label;
  final String value;

  const _PetInfoTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 14, color: Colors.purple),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

class _NavButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget targetScreen;

  const _NavButton(
      {required this.icon, required this.label, required this.targetScreen});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => targetScreen),
        );
      },
      child: Column(
        children: [
          Icon(icon, size: 30, color: Colors.purple),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 14, color: Colors.purple)),
        ],
      ),
    );
  }
}
