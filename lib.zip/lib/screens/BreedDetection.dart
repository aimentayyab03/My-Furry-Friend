import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class Breeddetection extends StatefulWidget {
  const Breeddetection({super.key});

  @override
  State<Breeddetection> createState() => _BreeddetectionState();
}

class _BreeddetectionState extends State<Breeddetection> {
  File? _image; // Store the picked image

  // Function to pick image from gallery
  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      setState(() {
        _image = File(image.path); // Store the image in state
      });
    }
  }

  // Function to capture image from camera
  Future<void> _captureImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.camera);

    if (image != null) {
      setState(() {
        _image = File(image.path); // Store the image in state
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text('Breed Detection'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Upload or Capture Your Pet\'s Photo to Detect Breed',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),

            // Display the image preview if an image is selected
            _image == null
                ? const Text(
              'No image selected.',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            )
                : Image.file(_image!, height: 250, width: 250, fit: BoxFit.cover),

            const SizedBox(height: 20),

            // Buttons to choose image source (Gallery or Camera)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: _pickImage,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                  child: const Row(
                    children: [
                      Icon(Icons.photo),
                      SizedBox(width: 8),
                      Text('Upload Photo'),
                    ],
                  ),
                ),
                const SizedBox(width: 20),
                ElevatedButton(
                  onPressed: _captureImage,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
                  child: const Row(
                    children: [
                      Icon(Icons.camera_alt),
                      SizedBox(width: 8),
                      Text('Take Photo'),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Button to detect breed (you can implement the model processing here)
            ElevatedButton(
              onPressed: _image == null
                  ? null
                  : () {
                // Call breed detection function here
                // Example: detectBreed(_image);
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.purple),
              child: const Text('Detect Breed'),
            ),
          ],
        ),
      ),
    );
  }
}
