import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _colorController = TextEditingController();
  final TextEditingController _aboutController = TextEditingController();

  Map<String, dynamic>? _petDetails;

  @override
  void initState() {
    super.initState();
    _loadPetDetails();
  }

  Future<void> _loadPetDetails() async {
    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      DocumentSnapshot userDoc =
      await _firestore.collection('users').doc(currentUser.uid).get();
      if (userDoc.exists && userDoc.data() != null) {
        setState(() {
          _petDetails = (userDoc.data() as Map<String, dynamic>)['pet'] ?? {};
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text('Profile'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: _petDetails == null
          ? const Center(child: CircularProgressIndicator())
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Pet Profile',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 20),
            CircleAvatar(
              radius: 50,
              backgroundColor: Colors.purple.shade100,
              backgroundImage: _petDetails!['image'] != null
                  ? NetworkImage(_petDetails!['image'])
                  : null,
              child: _petDetails!['image'] == null
                  ? const Icon(Icons.pets, size: 50, color: Colors.white)
                  : null,
            ),
            const SizedBox(height: 20),
            _buildProfileField('Name', _petDetails!['name']),
            _buildProfileField('Age', _petDetails!['age']),
            _buildProfileField('Weight', _petDetails!['weight']),
            _buildProfileField('Height', _petDetails!['height']),
            _buildProfileField('Color', _petDetails!['color']),
            const SizedBox(height: 10),
            const Text(
              'About Pet',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _petDetails!['about'] ?? 'No description available.',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            _buildEditButton(context),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileField(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Text(
            '$label: ',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.purple,
            ),
          ),
          Text(
            value?.toString() ?? 'Unknown',
            style: const TextStyle(fontSize: 16, color: Colors.black87),
          ),
        ],
      ),
    );
  }

  Widget _buildEditButton(BuildContext context) {
    return ElevatedButton(
      onPressed: _showEditProfileDialog,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.purple,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
      ),
      child: const Text(
        'Edit Profile',
        style: TextStyle(color: Colors.white),
      ),
    );
  }

  void _showEditProfileDialog() {
    _nameController.text = _petDetails?['name'] ?? '';
    _ageController.text = _petDetails?['age'] ?? '';
    _weightController.text = _petDetails?['weight'] ?? '';
    _heightController.text = _petDetails?['height'] ?? '';
    _colorController.text = _petDetails?['color'] ?? '';
    _aboutController.text = _petDetails?['about'] ?? '';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            'Edit Pet Profile',
            style: TextStyle(color: Colors.purple),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                _buildTextField('Name', _nameController),
                _buildTextField('Age', _ageController),
                _buildTextField('Weight', _weightController),
                _buildTextField('Height', _heightController),
                _buildTextField('Color', _colorController),
                _buildTextField('About Pet', _aboutController),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child:
              const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: _saveProfile,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
              ),
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.purple),
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.purple),
          ),
        ),
      ),
    );
  }

  void _saveProfile() async {
    final updatedPetDetails = {
      'name': _nameController.text,
      'age': _ageController.text,
      'weight': _weightController.text,
      'height': _heightController.text,
      'color': _colorController.text,
      'about': _aboutController.text,
    };

    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      await _firestore.collection('users').doc(currentUser.uid).update({
        'pet': updatedPetDetails,
      });

      setState(() {
        _petDetails = updatedPetDetails;
      });

      Navigator.pop(context); // Close the dialog
    }
  }
}
