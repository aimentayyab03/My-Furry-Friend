// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:mff/screens/wrapper.dart';
// import 'package:mff/services/auth.dart';
//
// class VerificationScreen extends StatelessWidget {
//   const VerificationScreen({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Verify Your Email'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(20.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             const Text(
//               'A verification email has been sent to your email address. Please verify your email to continue.',
//               style: TextStyle(fontSize: 16),
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () async {
//                 // Resend verification email
//                 await FirebaseAuth.instance.currentUser?.sendEmailVerification();
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   const SnackBar(content: Text('Verification email resent.')),
//                 );
//               },
//               child: const Text('Resend Email'),
//             ),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () async {
//                 // Check if the email is verified
//                 final isVerified = await AuthService().isEmailVerified();
//                 if (isVerified) {
//                   Navigator.pushReplacement(
//                     context,
//                     MaterialPageRoute(builder: (context) => Wrapper()),
//                   );
//                 } else {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('Email not verified yet.')),
//                   );
//                 }
//               },
//               child: const Text('I Have Verified My Email'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
