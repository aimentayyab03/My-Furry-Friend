import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HealthScreen extends StatefulWidget {
  const HealthScreen({super.key});

  @override
  State<HealthScreen> createState() => _HealthScreenState();
}

class _HealthScreenState extends State<HealthScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final TextEditingController _healthRecordController = TextEditingController();

  // List to hold health records
  List<Map<String, dynamic>> _healthRecords = [];

  @override
  void initState() {
    super.initState();
    _loadHealthRecords();
  }

  // Load health records from Firestore
  _loadHealthRecords() async {
    final currentUser = _auth.currentUser;
    if (currentUser != null) {
      final querySnapshot = await _firestore
          .collection('health_records')
          .where('uid', isEqualTo: currentUser.uid)
          .orderBy('timestamp', descending: true)
          .get();

      setState(() {
        _healthRecords = querySnapshot.docs
            .map((doc) => doc.data())
            .toList();
      });
    }
  }

  // Add a new health record
  _addHealthRecord() async {
    if (_healthRecordController.text.isNotEmpty) {
      final currentUser = _auth.currentUser;
      if (currentUser != null) {
        final newRecord = {
          'uid': currentUser.uid,
          'record': _healthRecordController.text,
          'timestamp': FieldValue.serverTimestamp(),
        };

        await _firestore.collection('health_records').add(newRecord);
        _healthRecordController.clear();  // Clear input field
        _loadHealthRecords();  // Reload health records after adding new one
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text('Health Tracker'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Monitor Your Pet\'s Health',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 20),
            _buildHealthRecordInputField(),
            const SizedBox(height: 20),
            const Text(
              'Health Records',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _healthRecords.isEmpty
                  ? const Center(child: Text('No health records yet!'))
                  : ListView.builder(
                itemCount: _healthRecords.length,
                itemBuilder: (context, index) {
                  final record = _healthRecords[index];
                  return _buildHealthRecordCard(record);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build input field for adding health records
  Widget _buildHealthRecordInputField() {
    return TextField(
      controller: _healthRecordController,
      decoration: InputDecoration(
        labelText: 'Add a health update',
        labelStyle: const TextStyle(color: Colors.purple),
        focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.purple),
        ),
        border: const OutlineInputBorder(),
        suffixIcon: IconButton(
          icon: const Icon(Icons.add, color: Colors.purple),
          onPressed: _addHealthRecord,
        ),
      ),
      maxLines: null, // Allows the text field to grow for multiple lines
    );
  }

  // Build each health record card to display in the list
  Widget _buildHealthRecordCard(Map<String, dynamic> record) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Health Update:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              record['record'] ?? 'No record available',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  _formatTimestamp(record['timestamp']),
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Format timestamp for each health record
  String _formatTimestamp(Timestamp timestamp) {
    final dateTime = timestamp.toDate();
    return '${dateTime.month}/${dateTime.day}/${dateTime.year} ${dateTime.hour}:${dateTime.minute}';
  }
}
