import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SocialScreen extends StatefulWidget {
  const SocialScreen({super.key});

  @override
  State<SocialScreen> createState() => _SocialScreenState();
}

class _SocialScreenState extends State<SocialScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final TextEditingController _postController = TextEditingController();

  // List to hold pet posts
  List<Map<String, dynamic>> _posts = [];

  @override
  void initState() {
    super.initState();
    _loadPosts();
  }

  // Load pet posts from Firestore
  _loadPosts() async {
    final querySnapshot =
    await _firestore.collection('posts').orderBy('timestamp', descending: true).get();

    setState(() {
      _posts = querySnapshot.docs
          .map((doc) => doc.data())
          .toList();
    });
  }

  // Handle posting new update
  _addPost() async {
    if (_postController.text.isNotEmpty) {
      final currentUser = _auth.currentUser;
      if (currentUser != null) {
        final newPost = {
          'uid': currentUser.uid,
          'name': currentUser.displayName ?? 'Unknown User',
          'post': _postController.text,
          'timestamp': FieldValue.serverTimestamp(),
        };

        await _firestore.collection('posts').add(newPost);
        _postController.clear();  // Clear the input field after posting
        _loadPosts();  // Reload posts after adding a new one
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text('Social Feed'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Share Updates About Your Pet!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 20),
            _buildPostInputField(),
            const SizedBox(height: 20),
            const Text(
              'Recent Posts',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _posts.isEmpty
                  ? const Center(child: Text('No posts yet! Be the first to share.'))
                  : ListView.builder(
                itemCount: _posts.length,
                itemBuilder: (context, index) {
                  final post = _posts[index];
                  return _buildPostCard(post);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build the post input field for creating a new post
  Widget _buildPostInputField() {
    return TextField(
      controller: _postController,
      decoration: InputDecoration(
        labelText: 'What\'s new with your pet?',
        labelStyle: const TextStyle(color: Colors.purple),
        focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: Colors.purple),
        ),
        border: const OutlineInputBorder(),
        suffixIcon: IconButton(
          icon: const Icon(Icons.send, color: Colors.purple),
          onPressed: _addPost,
        ),
      ),
      maxLines: null,  // Allows the text field to grow for multiple lines
    );
  }

  // Build each post card to display in the social feed
  Widget _buildPostCard(Map<String, dynamic> post) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              post['name'] ?? 'Unknown User',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              post['post'] ?? 'No content',
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  _formatTimestamp(post['timestamp']),
                  style: const TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Format timestamp for each post
  String _formatTimestamp(Timestamp timestamp) {
    final dateTime = timestamp.toDate();
    return '${dateTime.month}/${dateTime.day}/${dateTime.year} ${dateTime.hour}:${dateTime.minute}';
  }
}
