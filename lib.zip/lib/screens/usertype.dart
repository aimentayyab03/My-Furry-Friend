import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mff/screens/petdetails.dart';

class UserType extends StatefulWidget {
  const UserType({super.key});

  @override
  _UserTypeState createState() => _UserTypeState();
}

class _UserTypeState extends State<UserType> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select User Type'),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Select your user type:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.purple),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => saveUserType('Pet Owner'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple.shade200,
                      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'Pet Owner',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () => saveUserType('Pet Accessory Seller'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple.shade200,
                      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'Pet Accessory Seller',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () => saveUserType('Pet Adopter'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.purple.shade200,
                      padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 40),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'Pet Adopter',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void saveUserType(String userType) async {
    try {
      User? currentUser = _auth.currentUser;

      if (currentUser != null) {
        // Attempt to update or set the userType field in Firestore
        DocumentReference userDoc = _firestore.collection('users').doc(currentUser.uid);

        // Use set with merge: true to ensure it doesn't overwrite other existing fields in the document
        await userDoc.set({
          'userType': userType,
        }, SetOptions(merge: true));  // This will merge userType without overwriting other fields

        // Navigate based on user type
        if (userType == 'Pet Owner') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const PetDetails()), // Navigate to PetDetails if Pet Owner
          );
        } else if (userType == 'Pet Accessory Seller') {
          // Navigate to the pet accessory seller's page (you need to define this screen)
          // Navigator.pushReplacement(
          //   context,
          //   MaterialPageRoute(builder: (context) => const Pethomepage()), // Example: Navigate to Pet HomePage
          // );
        } else if (userType == 'Pet Adopter') {
          // Navigate to the pet adopter's page (you need to define this screen)
          // Navigator.pushReplacement(
          //   context,
          //   MaterialPageRoute(builder: (context) => const Pethomepage()), // Example: Navigate to Pet HomePage
          // );
        }
      }
      else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No user is signed in.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to save user type: ${e.toString()}')),
      );
    }
  }
}
