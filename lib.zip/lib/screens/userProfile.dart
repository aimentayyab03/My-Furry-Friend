// user_profile_screen.dart (StatefulWidget)
import 'package:flutter/material.dart';
import 'package:mff/services/firestore_service.dart';

class UserProfile extends StatelessWidget {
  final FirestoreService _firestoreService = FirestoreService();

  UserProfile({super.key});

  void _updateUserProfile(String userId) {
    Map<String, dynamic> updatedData = {
      'username': 'Updated Username',
      'email': 'updatedemail@example.com',
    };

    _firestoreService.updateUserDocument(userId, updatedData);
  }

  @override
  Widget build(BuildContext context) {
    const String userId = 'poRkQtRgAoPvHGmHt6LtmGg7Y9l1'; // Example user ID

    return Scaffold(
      appBar: AppBar(title: const Text('User Profile')),
      body: Center(
        child: ElevatedButton(
          onPressed: () => _updateUserProfile(userId),
          child: const Text('Update Profile'),
        ),
      ),
    );
  }
}
