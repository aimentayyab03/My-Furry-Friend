import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:mff/screens/login.dart';
import 'package:mff/screens/pethomepage.dart';
import 'package:mff/services/auth.dart'; // Assuming you have an AuthService to check user existence

class Wrapper extends StatelessWidget {
  final AuthService _authService = AuthService();

  Wrapper({super.key}); // Initialize the AuthService to check user data

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        // Show loading indicator while checking authentication state
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        // If there's no user logged in, redirect to login page
        if (!snapshot.hasData || snapshot.data == null) {
          return const Login();
        }

        final User user = snapshot.data!;

        // Check if the user has a valid email
        if (user.email == null || user.email!.isEmpty) {
          return const Login(); // If no email, redirect to login
        }

        return FutureBuilder<bool>(
          future: _authService.userExists(user.email!),
          builder: (context, userExistsSnapshot) {
            if (userExistsSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(
                  child: CircularProgressIndicator(),
                ),
              );
            }

            if (userExistsSnapshot.hasData && userExistsSnapshot.data!) {
              // If user exists in the database, navigate to Pethomepage
              return const Pethomepage();
            } else {
              // If user does not exist, redirect to login
              return const Login();
            }
          },
        );
      },
    );
  }
}
