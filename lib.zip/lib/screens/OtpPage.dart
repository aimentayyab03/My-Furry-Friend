// import 'package:flutter/material.dart';
// import 'package:sms_autofill/sms_autofill.dart';
// import '../services/auth.dart';
//
// class OtpPage extends StatefulWidget {
//   final String vid; // Verification ID
//
//   const OtpPage({Key? key, required this.vid}) : super(key: key);
//
//   @override
//   _OtpPageState createState() => _OtpPageState();
// }
//
//
// class _OtpPageState extends State<OtpPage> with CodeAutoFill {
//   final TextEditingController _otpController = TextEditingController();
//   final AuthService _authService = AuthService();
//   String? _code;
//
//   @override
//   void initState() {
//     super.initState();
//     listenForCode(); // Start listening for SMS autofill
//   }
//
//   @override
//   void dispose() {
//     cancel(); // Stop listening when widget is disposed
//     super.dispose();
//   }
//
//   @override
//   void codeUpdated() {
//     setState(() {
//       _code = code;
//       _otpController.text = _code ?? '';
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Verify OTP")),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             // OTP Image
//             Center(
//               child: SizedBox(
//                 width: 200,
//                 height: 200,
//                 child: Image.asset('assets/images/otp.png'),
//               ),
//             ),
//             const SizedBox(height: 20),
//
//             // Instruction Text
//             const Text(
//               'Enter the OTP sent to your phone',
//               style: TextStyle(fontSize: 18),
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 20),
//
//             // OTP TextField with Auto-fill
//             PinFieldAutoFill(
//               controller: _otpController,
//               codeLength: 6, // Adjust OTP length as per requirement
//               onCodeChanged: (code) {
//                 if (code?.length == 6) {
//                   print('OTP Auto-filled: $code');
//                 }
//               },
//               decoration: BoxLooseDecoration(
//                 strokeColorBuilder: FixedColorBuilder(Colors.grey),
//               ),
//             ),
//             const SizedBox(height: 20),
//
//             // Verify OTP Button
//             ElevatedButton(
//               onPressed: () async {
//                 String otp = _otpController.text.trim();
//                 if (otp.isEmpty || otp.length < 6) {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('Please enter a valid OTP')),
//                   );
//                   return;
//                 }
//
//                 try {
//                   // Use AuthService to verify OTP
//                   await _authService.verifyOtp(otp, widget.vid); // Pass OTP and verificationId
//
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('OTP Verified!')),
//                   );
//
//                   // Navigate to the next screen after verification
//                   Navigator.of(context).pop();
//                 } catch (e) {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     SnackBar(content: Text('Error: ${e.toString()}')),
//                   );
//                 }
//               },
//               child: const Text('Verify OTP'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
