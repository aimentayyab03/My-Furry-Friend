import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:mff/screens/wrapper.dart';  // Ensure this is imported correctly
import 'package:mff/src/utils/themes/theme.dart';  // Ensure theme file is correct

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Furry Friend',
      theme: TApptheme.lightTheme,
      darkTheme: TApptheme.darkTheme,
      themeMode: ThemeMode.system,
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();

    // Navigate to the Wrapper screen after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) =>  Wrapper()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              child: Image.asset('assets/images/petlogo.png'),
            ),
            const SizedBox(height: 20),
            const Text(
              'MY FURRY FRIEND',
              style: TextStyle(
                fontSize: 24,
                fontFamily: 'DancingScript',
                fontWeight: FontWeight.bold,
                color: Colors.purple,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
